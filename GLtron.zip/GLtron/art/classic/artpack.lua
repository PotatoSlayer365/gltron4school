settings.show_gl_logo = 1
