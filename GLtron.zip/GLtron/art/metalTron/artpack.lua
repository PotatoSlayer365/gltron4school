clear_color = { 0, 0, 0, 0 }
settings.show_skybox = 1
